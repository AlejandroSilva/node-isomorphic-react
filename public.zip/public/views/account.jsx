
'use strict';

var React = require('react');

module.exports = React.createClass({

    displayName: 'account',

    onButtonClick: function() {
        alert('I was rendered on server side but I am clickable because of client mounting!');
    },

    render: function render() {

        return (
            <div id='account'>
                <h1>{this.props.name}</h1>
                <h6>I am a React Router rendered view</h6>
                <button onClick={this.onButtonClick}>___Click Me___</button>
                <a href='/some_unknown'>Click to go to an unhandled route</a>
            </div>
        );
    }
});